# Shrimple [shader]

A very minimal shader that only adds shadows and dynamic/colored lighting. Requires Iris 1.6 or later!
